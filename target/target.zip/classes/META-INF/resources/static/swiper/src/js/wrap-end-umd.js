	return Swiper;
}));
