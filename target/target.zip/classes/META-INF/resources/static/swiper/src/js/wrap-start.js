(function () {
    'use strict';
    var $;
