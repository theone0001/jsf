package com.mzq.gym.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

/**
 * @Description: 私教信息实体类
 */
@Entity
@Table(name = "privatecoachinfo")
@Getter
@Setter
public class PrivateCoachInfo implements java.io.Serializable
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long pid;
    @ManyToOne
    @JoinColumn(name = "subjectid")
    private Subject subject;

    @OneToOne
    @JoinColumn(name = "coachid")
    private User coach;

    @ManyToOne
    @JoinColumn(name = "memberid")
    private User member;
    private int count;
    private double countprice;
    private double realprice;
    private java.sql.Date date;
    private int state;
    private String remark;
    private String admin;
}
