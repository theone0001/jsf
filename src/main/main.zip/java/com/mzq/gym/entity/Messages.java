package com.mzq.gym.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

/**
 * @Description: 留言板
 */
@Entity
@Table(name = "messages")
@Getter
@Setter
public class Messages
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @ManyToOne
    @JoinColumn(name = "userid")
    private User user;

    @Column(name = "message", nullable = false)
    private String message;

    private String date;
}
