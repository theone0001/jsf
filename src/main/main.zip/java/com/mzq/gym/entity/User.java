package com.mzq.gym.entity;


import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

/**
 * @Description: 用户信息实体类
 */
@Entity
@Table(name = "user")
@Getter
@Setter
public class User
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String loginName;
    private String password;
    private Integer type;
    private String name;
    private String phone;
    private Integer sex;
    private Integer age;
    private java.sql.Date coachDate;
    private Integer coachTeach;
    private Double coachWages;
    private Integer coachStatic;
    private String coachAddress;
    @ManyToOne
    @JoinColumn(name = "memberTypes")
    private Membertype memberTypes;
    private String memberBirthday;
    private java.sql.Date memberDate;
    private Integer memberStatic;
    private Float memberBalance;
    private java.sql.Date memberXufei;
}
