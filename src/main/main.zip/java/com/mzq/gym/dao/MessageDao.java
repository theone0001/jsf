package com.mzq.gym.dao;


import com.mzq.gym.entity.Messages;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * @Description: 留言板Dao层接口
 */
public interface MessageDao extends JpaRepository<Messages, Long>
{

    @Query(value = "select * FROM  Messages where userid =:userid", nativeQuery = true)
    List<Messages> findMessagesByUserId(@Param("userid") long userid);
}
