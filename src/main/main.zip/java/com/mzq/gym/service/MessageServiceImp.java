package com.mzq.gym.service;


import com.mzq.gym.entity.Messages;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


/**
 * @Description: 留言板接口
 * @Author: JL
 * @Date: 2022/5/17
 */
@Service
public class MessageServiceImp
{

    @PersistenceContext
    private EntityManager entityManager;

    public String getDate()
    {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date now = new Date();
        return sdf.format(now);
    }

    public List<Messages> query(int page, int size)
    {
        String jpal = "from Messages Order by date desc";
        Query qu = entityManager.createQuery(jpal);
        //起始页书
        qu.setFirstResult(page);
        //结束页数
        qu.setMaxResults(size);

        return qu.getResultList();
    }
}
