package com.mzq.gym.service;

import com.mzq.gym.dao.GoodInfoDao;
import com.mzq.gym.dao.PrivateCoachInfoDao;
import com.mzq.gym.dao.UserDao;
import com.mzq.gym.dao.chongzhiDao;
import com.mzq.gym.entity.Chongzhi;
import com.mzq.gym.entity.GoodInfo;
import com.mzq.gym.entity.PrivateCoachInfo;
import com.mzq.gym.entity.User;
import com.mzq.gym.enums.UserType;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Description: 会员管理service实现层
 * @Author: JL
 * @Date: 2022/4/6
 */
@Service
public class MemberDaoImpl
{


    @Autowired
    private UserDao userDao;

    @Autowired
    private PrivateCoachInfoDao privateCoachInfoDao;

    @Autowired
    private GoodInfoDao goodInfoDao;

    @Autowired
    private chongzhiDao chongZhiDao;

    @PersistenceContext
    private EntityManager entityManager;

    @Value("${custom.default.password}")
    private String defaultPassword;

    /**
     * @Description: 会员管理service实现层-分页查询
     * @Author: JL
     * @Date: 2022/4/6
     */
    public Map<String, Object> query(Map<String, Object> map1)
    {
        //根据会员到期的日期修改到期后状态
        List<User> memberslist = userDao.findByType(UserType.MEMBER.getType());
        //得到现在的时间
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String date = sdf.format(new Date());
        try
        {
            Date now = sdf.parse(date);
            for (User member : memberslist)
            {
                //得到会员到期时间
                String date1 = member.getMemberXufei().toString();
                if (date1 == null)
                {
                    date1 = date;
                }
                Date daoqi = sdf.parse(date1);
                if (daoqi.before(now))
                {
                    //设置会员状态为不正常
                    member.setMemberStatic(2);
                }
                else
                {
                    //设置会员状态为正常
                    member.setMemberStatic(1);
                }
                userDao.save(member);
            }
        }
        catch (ParseException e)
        {
            e.printStackTrace();
        }
        //分页
        String jpal = "from User where type = " + UserType.MEMBER.getType();
        if (map1.get("hyname") != null && !map1.get("hyname").equals(""))
        {
            jpal = jpal + " and name like '%" + map1.get("hyname") + "%'";
        }
        long ktype = (long) map1.get("ktype");
        if (ktype != 0)
        {
            jpal = jpal + "and memberTypes=" + ktype;
        }
        Query qu = entityManager.createQuery(jpal);
        //起始页书
        qu.setFirstResult((int) map1.get("qi"));
        //结束页数
        qu.setMaxResults((int) map1.get("shi"));

        //查询多少条数据
        String jpa = "select count(m) from User m where type = " + UserType.MEMBER.getType();

        if (map1.get("hyname") != null && !map1.get("hyname").equals(""))
        {
            jpa = jpa + " and name like '%" + map1.get("hyname") + "%'";
        }
        if (ktype != 0)
        {
            jpa = jpa + " and memberTypes=" + ktype;
        }
        Long count = (Long) entityManager.createQuery(jpa).getSingleResult();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("total", count);
        map.put("rows", qu.getResultList());
        return map;
    }

    /**
     * @Description: 会员管理service实现层-会员到期分页查询
     * @Author: JL
     * @Date: 2022/4/6
     */
    //会员到期查询
    public Map<String, Object> query2(Map<String, Object> map1)
    {
        //分页
        String jpal = "from User where type = " + UserType.MEMBER.getType();
        if (map1.get("hyname") != null && !map1.get("hyname").equals(""))
        {
            jpal = jpal + " and name like '%" + map1.get("hyname") + "%'";
        }
        long ktype = (long) map1.get("ktype");
        if (ktype != 0)
        {
            jpal = jpal + " and memberTypes=" + ktype;
        }
        jpal += " and memberStatic = 2";
        Query qu = entityManager.createQuery(jpal);
        //起始页书
        qu.setFirstResult((int) map1.get("qi"));
        //结束页数
        qu.setMaxResults((int) map1.get("shi"));

        //查询多少条数据
        String jpa = "select count(m) from User m where type = " + UserType.MEMBER.getType();

        if (map1.get("hyname") != null && !map1.get("hyname").equals(""))
        {
            jpa = jpa + " and name like '%" + map1.get("hyname") + "%'";
        }
        if (ktype != 0)
        {
            jpa = jpa + " and memberTypes=" + ktype;
        }
        jpa += " and memberStatic = 2";
        Long count = (Long) entityManager.createQuery(jpa).getSingleResult();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("total", count);
        map.put("rows", qu.getResultList());
        return map;
    }

    /**
     * @Description: 会员管理service实现层-根据会员id删除
     * @Author: JL
     * @Date: 2022/4/6
     */
    public int del(long id)
    {
        //先根据会员id在私教信息表里查询是否有其信息
        List<PrivateCoachInfo> privateCoachInfoList = privateCoachInfoDao.queryByIdNative(id);
        if (privateCoachInfoList != null && privateCoachInfoList.size() > 0)
        {
            //如果有,先循环删除
            for (PrivateCoachInfo privateCoachInfo : privateCoachInfoList)
            {
                if (id == privateCoachInfo.getMember().getId())
                {
                    privateCoachInfoDao.delete(privateCoachInfo);
                }
            }
        }
        //再根据会员id在商品信息表中查是否有其信息
        List<GoodInfo> goodInfoList = goodInfoDao.queryByIdNative(id);
        if (goodInfoList != null && goodInfoList.size() > 0)
        {
            for (GoodInfo goodInfo : goodInfoList)
            {
                if (id == goodInfo.getMember().getId())
                {
                    goodInfoDao.delete(goodInfo);
                }
            }
        }
        //根据会员id在充值信息表中查询是否有其信息
        List<Chongzhi> chongzhiList = chongZhiDao.queryByIdNative(id);
        if (chongzhiList != null && chongzhiList.size() > 0)
        {
            for (Chongzhi chongzhi : chongzhiList)
            {
                if (id == chongzhi.getMember().getId())
                {
                    chongZhiDao.delete(chongzhi);
                }
            }
        }
        //最后删除此会员
        userDao.deleteById(id);
        return 1;
    }


    /**
     * @Description: 会员管理service实现层-添加会员
     * @Author: JL
     * @Date: 2022/4/6
     */
    public int insert(User member)
    {
        member.setPassword(DigestUtils.md5Hex(defaultPassword));
        member.setType(UserType.MEMBER.getType());
        member.setMemberStatic(1);
        member.setMemberBalance(0f);
        userDao.save(member);
        return 1;
    }

    /**
     * @Description: 会员管理service实现层-修改会员信息
     * @Author: JL
     * @Date: 2022/4/6
     */
    public void update(User member)
    {
        Optional<User> user = userDao.findById(member.getId());
        if (user.isPresent() && UserType.MEMBER.getType().equals(user.get().getType()))
        {
            User one = user.get();
            member.setLoginName(one.getLoginName());
            member.setPassword(one.getPassword());
            member.setType(one.getType());
            userDao.save(member);
        }
    }

    /**
     * @Description: 会员管理service实现层-根据id查询会员信息
     * @Author: JL
     * @Date: 2022/4/6
     */
    public User cha(long id)
    {
        return userDao.findById(id).get();
    }

    /**
     * @Description: 会员管理service实现层-修改会员信息
     * @Author: JL
     * @Date: 2022/4/6
     */
    public void upd(User member)
    {
        User one = userDao.findById(member.getId()).get();
        one.setMemberBalance(member.getMemberBalance());
        userDao.save(one);
    }
}
