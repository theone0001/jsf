package com.mzq.gym.controller;


import com.mzq.gym.dao.UserDao;
import com.mzq.gym.entity.Chongzhi;
import com.mzq.gym.entity.User;
import com.mzq.gym.service.MemberDaoImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Description: 会员充值管理Controller控制层
 */
@Controller
@RequestMapping("/cz")
public class chongzhiController {

    @Autowired
    private com.mzq.gym.dao.chongzhiDao chongzhiDao;

    @Autowired
    private UserDao userDao;

    @Autowired
    private MemberDaoImpl memberDaoImpl;

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * @Description: 会员充值管理-进入会员充值记录界面
     */
    @RequestMapping("/jin")
    public String jin() {
        return "WEB-INF/jsp/HYMemberjilu";
    }


    /**
     * @Description: 会员余额充值
     */
    @RequestMapping("/xin")
    @ResponseBody
    public Map<String, Object> cye(Chongzhi chongzhi) {

        //充值money
        User member = userDao.findById(chongzhi.getMember().getId()).get();
        member.setMemberBalance(member.getMemberBalance() + chongzhi.getMoney());
        userDao.save(member);

        //添加充值记录
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        java.sql.Timestamp dat = java.sql.Timestamp.valueOf(df.format(new Date()));
        chongzhi.setDate(dat);
        chongzhi.setCzStatic(1L);
        chongzhiDao.save(chongzhi);
        Map<String, Object> map1 = new HashMap<String, Object>();
        map1.put("hyname", null);
        map1.put("ktype", 0L);
        map1.put("qi", 1);
        map1.put("shi", 5);
        return memberDaoImpl.query(map1);
    }

    /**
     * @Description: 续费续卡记录-根据所选日期分页查询数据记录
     */
    @RequestMapping("/query")
    @ResponseBody
    public Map<String, Object> query(int pageSize, int pageNumber, String xdate, String ddate) throws ParseException {
        Map<String, Object> map = new HashMap();
        if (xdate.equals("")) {
            xdate = "2022-01-01 00:00:00";
        } else {
            xdate = xdate + " 00:00:00";
        }
        if (ddate.equals("")) {
            ddate = "2100-01-01 23:59:59";
        } else {
            ddate = ddate + " 23:59:59";
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        final Date startTime = sdf.parse(xdate);
        final Date endTime = sdf.parse(ddate);
        Pageable pageable = new PageRequest(pageNumber - 1, pageSize);
        Specification<Chongzhi> specification = new Specification<Chongzhi>() {
            @Override
            public Predicate toPredicate(Root<Chongzhi> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
                List<Predicate> list = new ArrayList<Predicate>();
                list.add(criteriaBuilder.between(root.<Date>get("date"), startTime, endTime));

                return criteriaBuilder.and(list.toArray(new Predicate[list.size()]));
            }
        };
        Page<Chongzhi> list1 = chongzhiDao.findAll(specification, pageable);
        List<Chongzhi> li = list1.getContent();
        map.put("total", list1.getTotalElements());
        map.put("rows", li);
        return map;
    }

}